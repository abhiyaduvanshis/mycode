import { Component, OnInit } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styles: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

    form        :  FormGroup;
    first_name  :  string;
    last_name   :  string;
    email       :  string;
    password    :  string;
    phone       :  string;
    company     :  string;
    results     :  any = null;


  private formSumitAttempt: boolean;

  constructor(private http: Http, private formBuilder: FormBuilder) {}

  ngOnInit() {
    this.form = this.formBuilder.group({

      first_name: [null, Validators.required],
      last_name: [null, Validators.required],
      email: [null, [Validators.required, Validators.email]],
      password: [null, Validators.required],
      phone: [null, Validators.required],
      company: [null, Validators.required]

    });
  }

  isFieldValid(field: string) {
    return (
      (!this.form.get(field).valid && this.form.get(field).touched) ||
      (this.form.get(field).untouched && this.formSumitAttempt)
    );
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  onSubmit() {
    this.formSumitAttempt = true;
    if (this.form.valid) {
     
      const uri  = 'http://localhost/angapi/Register/Add_register';

      let obj    = {  

      first_name  :  this.form.value.first_name,
      last_name   :  this.form.value.last_name,
      email       :  this.form.value.email,
      password    :  this.form.value.password,
      phone       :  this.form.value.phone,
      company     :  this.form.value.company
      };
    
      this.http.post(uri,obj)
       .map((res: Response) => res.json())
       .subscribe(
        results => {
        this.results = results; 
        console.log(this.results.msg);
      });

    }
  }

  reset() {
    this.form.reset();
    this.formSumitAttempt = false;
  }

  logout() {

       localStorage.removeItem('user');
          
   }
}
