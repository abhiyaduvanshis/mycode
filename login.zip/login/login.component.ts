import { Component, OnInit } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

    form        :  FormGroup;
    email       :  string;
    password    :  string;
    results     :  any = null;

    private formSumitAttempt: boolean;


  constructor(private http: Http, private formBuilder: FormBuilder,private router: Router) { }

    ngOnInit() {
    this.form = this.formBuilder.group({

      email: [null, [Validators.required, Validators.email]],
      password: [null, Validators.required]

    });
  }

  isFieldValid(field: string) {
    return (
      (!this.form.get(field).valid && this.form.get(field).touched) ||
      (this.form.get(field).untouched && this.formSumitAttempt)
    );
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  onSubmit() {
    this.formSumitAttempt = true;
    if (this.form.valid) {
     
      const uri  = 'http://localhost/angapi/Login';

      let obj    = {  

      email       :  this.form.value.email,
      password    :  this.form.value.password
      };
    
      this.http.post(uri,obj)
       .map((res: Response) => res.json())
       .subscribe(
        results => {
        this.results = results; 
       
          if(this.results.token){
          localStorage.setItem("user",this.results.token);
          localStorage.setItem("useremail",this.results.email);
          this.router.navigate(['/home']);
          }else{
          this.router.navigate(['/login']);
        }
      });

    }
  }

  reset() {
    this.form.reset();
    this.formSumitAttempt = false;
  }

}
