import { Component, OnInit } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
import {NgxPaginationModule} from 'ngx-pagination';

@Component({

  selector: 'app-userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.css']

})

export class UserlistComponent implements OnInit {

results:  any = null;

  constructor(private http: Http) { }
  page :number = 1;

    ngOnInit(): void {

        this.http.get('http://localhost/e-fileing-itr/pages/getuserapi')
        .map((res: Response) => res.json())
        .subscribe(results => {
        this.results = results;
        console.log(this.results);
      
    });

  }


}
